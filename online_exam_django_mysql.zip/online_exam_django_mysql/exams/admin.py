from django.contrib import admin
from .models import StudentProfile, Exam, Question, Option, ExamQuestion, Attempt, Answer

class OptionInline(admin.TabularInline):
    model = Option
    extra = 1

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('id','text','marks','difficulty','created_by')
    inlines = [OptionInline]

@admin.register(Exam)
class ExamAdmin(admin.ModelAdmin):
    list_display = ('id','title','duration_minutes','start_time','end_time','is_active','created_by')

@admin.register(ExamQuestion)
class ExamQuestionAdmin(admin.ModelAdmin):
    list_display = ('exam','question','order','shuffle_options')
    list_select_related = ('exam','question')

@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ('user','roll_no','class_name','section')

@admin.register(Attempt)
class AttemptAdmin(admin.ModelAdmin):
    list_display = ('id','exam','student','status','score','started_at','submitted_at')

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ('attempt','question','selected_option','is_correct')
