from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.contrib.auth.models import User
from django.http import JsonResponse, Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.db import transaction
from .models import Exam, ExamQuestion, Attempt, Answer, Option, StudentProfile
from .forms import SignUpForm

def signup(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            user, profile = form.save()
            login(request, user)
            return redirect('dashboard')
    else:
        form = SignUpForm()
    return render(request, "auth/signup.html", {"form": form})

@login_required
def dashboard(request):
    # Teachers see all exams; students see open exams
    if request.user.is_staff:
        exams = Exam.objects.all().order_by("-id")
    else:
        exams = Exam.objects.filter(is_active=True).order_by("-id")
    return render(request, "exams/dashboard.html", {"exams": exams})

@login_required
def start_exam(request, exam_id):
    exam = get_object_or_404(Exam, pk=exam_id)
    if not exam.is_open_now() or request.user.is_staff:
        raise Http404()
    student = get_object_or_404(StudentProfile, user=request.user)
    attempt, created = Attempt.objects.get_or_create(exam=exam, student=student)
    if attempt.status != "in_progress":
        return redirect("take_exam", attempt_id=attempt.id)
    return redirect("take_exam", attempt_id=attempt.id)

@login_required
def take_exam(request, attempt_id):
    attempt = get_object_or_404(Attempt, pk=attempt_id, student__user=request.user)
    exam = attempt.exam
    elapsed = (timezone.now() - attempt.started_at).total_seconds()
    remaining = max(0, exam.duration_minutes*60 - int(elapsed))
    if remaining == 0 and attempt.status == "in_progress":
        return submit_exam(request, attempt_id)  # force submit
    eqs = exam.exam_questions.select_related("question").order_by("order")
    return render(request, "exams/take_exam.html", {"attempt": attempt, "eqs": eqs, "remaining": remaining})

@transaction.atomic
@login_required
def save_answer(request, attempt_id):
    if request.method != "POST":
        return JsonResponse({"ok": False}, status=400)
    attempt = get_object_or_404(Attempt, pk=attempt_id, student__user=request.user, status="in_progress")
    qid = int(request.POST["question_id"])
    oid = request.POST.get("option_id")
    ans, _ = Answer.objects.get_or_create(attempt=attempt, question_id=qid)
    ans.selected_option_id = int(oid) if oid else None
    ans.is_correct = False
    if ans.selected_option_id:
        ans.is_correct = Option.objects.filter(id=ans.selected_option_id, is_correct=True).exists()
    ans.save()
    return JsonResponse({"ok": True})

@transaction.atomic
@login_required
def submit_exam(request, attempt_id):
    attempt = get_object_or_404(Attempt, pk=attempt_id, student__user=request.user)
    if attempt.status != "in_progress":
        return redirect("result_list")
    exam = attempt.exam
    total = 0
    for a in attempt.answers.select_related("question"):
        if a.is_correct:
            total += a.question.marks
    attempt.score = total
    attempt.status = "submitted"
    attempt.submitted_at = timezone.now()
    attempt.seconds_spent = int((attempt.submitted_at - attempt.started_at).total_seconds())
    attempt.save()
    return redirect("result_list")

@login_required
def result_list(request):
    if request.user.is_staff:
        attempts = Attempt.objects.select_related("student__user", "exam").order_by("-id")
    else:
        attempts = Attempt.objects.filter(student__user=request.user).select_related("exam").order_by("-id")
    return render(request, "exams/result_list.html", {"attempts": attempts})

@login_required
def report_pdf(request, attempt_id):
    attempt = get_object_or_404(Attempt, pk=attempt_id)
    if not (request.user.is_staff or attempt.student.user == request.user):
        raise Http404()
    content = (
        f"Report Card\n\nStudent: {attempt.student.user.get_full_name() or attempt.student.user.username}\n"
        f"Roll: {attempt.student.roll_no}\nExam: {attempt.exam.title}\n"
        f"Score: {attempt.score}\nDuration: {attempt.exam.duration_minutes} min\n"
        f"Started: {attempt.started_at}\nSubmitted: {attempt.submitted_at}\n"
    )
    response = HttpResponse(content, content_type="text/plain; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="report_{attempt.id}.txt"'
    return response
