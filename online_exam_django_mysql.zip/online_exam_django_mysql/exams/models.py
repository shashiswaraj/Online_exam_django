from django.conf import settings
from django.db import models
from django.utils import timezone

class StudentProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    roll_no = models.CharField(max_length=32, unique=True)
    class_name = models.CharField(max_length=64, blank=True)
    section = models.CharField(max_length=8, blank=True)
    def __str__(self): 
        return f"{self.roll_no} - {self.user.get_full_name() or self.user.username}"

class Exam(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    duration_minutes = models.PositiveIntegerField(default=30)
    total_marks = models.PositiveIntegerField(default=0)
    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=False)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="created_exams")
    def __str__(self): 
        return self.title
    def is_open_now(self):
        now = timezone.now()
        return self.is_active and (self.start_time is None or self.start_time <= now) and (self.end_time is None or now <= self.end_time)

class Question(models.Model):
    text = models.TextField()
    marks = models.PositiveIntegerField(default=1)
    difficulty = models.CharField(max_length=16, choices=[("easy","Easy"),("med","Medium"),("hard","Hard")], default="easy")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    def __str__(self): 
        return self.text[:50]

class Option(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name="options")
    text = models.CharField(max_length=500)
    is_correct = models.BooleanField(default=False)

class ExamQuestion(models.Model):
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name="exam_questions")
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    order = models.PositiveIntegerField(default=0)
    shuffle_options = models.BooleanField(default=True)

class Attempt(models.Model):
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name="attempts")
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name="attempts")
    started_at = models.DateTimeField(auto_now_add=True)
    submitted_at = models.DateTimeField(null=True, blank=True)
    score = models.FloatField(default=0)
    status = models.CharField(max_length=16, choices=[("in_progress","In Progress"),("submitted","Submitted"),("expired","Expired")], default="in_progress")
    seconds_spent = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = ("exam", "student")

class Answer(models.Model):
    attempt = models.ForeignKey(Attempt, on_delete=models.CASCADE, related_name="answers")
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    selected_option = models.ForeignKey(Option, null=True, blank=True, on_delete=models.SET_NULL)
    is_correct = models.BooleanField(default=False)

    class Meta:
        unique_together = ("attempt", "question")
