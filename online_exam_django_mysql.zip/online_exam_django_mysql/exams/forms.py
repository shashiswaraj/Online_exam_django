from django import forms
from django.contrib.auth.models import User
from .models import StudentProfile

class SignUpForm(forms.ModelForm):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)
    first_name = forms.CharField(max_length=150, required=False)
    last_name = forms.CharField(max_length=150, required=False)
    email = forms.EmailField(required=False)

    class Meta:
        model = StudentProfile
        fields = ['roll_no','class_name','section']

    def save(self):
        data = self.cleaned_data
        user = User.objects.create_user(
            username=data['username'],
            password=data['password'],
            first_name=data.get('first_name') or '',
            last_name=data.get('last_name') or '',
            email=data.get('email') or '',
        )
        profile = StudentProfile.objects.create(
            user=user,
            roll_no=data['roll_no'],
            class_name=data.get('class_name') or '',
            section=data.get('section') or '',
        )
        return user, profile
