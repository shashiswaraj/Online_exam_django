# Online Examination System (Django + MySQL)

## Quick Start (Local)
```bash
# 1) Create venv
python -m venv .venv
. .venv/Scripts/activate  # Windows
# or: source .venv/bin/activate  # macOS/Linux

# 2) Install deps
pip install -r requirements.txt

# 3) Configure DB
# Default: SQLite (no setup needed). For MySQL, set environment variables:
#   DB_ENGINE=mysql
#   DB_NAME=online_exam
#   DB_USER=root
#   DB_PASSWORD=yourpass
#   DB_HOST=127.0.0.1
#   DB_PORT=3306
#
# Windows PowerShell example:
#   $env:DB_ENGINE="mysql"
#   $env:DB_NAME="online_exam"
#   $env:DB_USER="root"
#   $env:DB_PASSWORD="yourpass"
#   $env:DB_HOST="127.0.0.1"
#   $env:DB_PORT="3306"

# 4) Django setup
python manage.py migrate
python manage.py createsuperuser

# 5) Run
python manage.py runserver
```

## Roles
- Use Django admin (`/admin`) to create Questions, Options, Exams, and to mark an Exam active.
- Students sign up/login via `/signup` and `/login`, then attempt open exams from dashboard.

## Features
- Student registration/login
- Teachers create question papers (MCQ) in Admin or via forms
- Exam timer (server-validated), autosave answers
- Auto evaluation and report download (TXT; swap to PDF via ReportLab template if desired)

## Notes
- DB defaults to SQLite for easy run; switch to MySQL by setting `DB_ENGINE=mysql` and normal MySQL env vars.
- Option shuffling and per-attempt order can be extended in `exams/views.py`.
