from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('exams/<int:exam_id>/start/', views.start_exam, name='start_exam'),
    path('attempt/<int:attempt_id>/', views.take_exam, name='take_exam'),
    path('attempt/<int:attempt_id>/save/', views.save_answer, name='save_answer'),
    path('attempt/<int:attempt_id>/submit/', views.submit_exam, name='submit_exam'),
    path('results/', views.result_list, name='result_list'),
    path('results/<int:attempt_id>/report/', views.report_pdf, name='report_pdf'),
]
